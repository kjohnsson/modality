# modality
Statistical tests for evaluating unimodality.

During installation, tablulated p-values for Hartigan's dip test
are obtained from the R package 'diptest'. If the package fails to load,
rpy2 tries to install it. Another way to install the 'diptest' R package
is to write "install.packages('diptest')" within R.

### Using mpi

from mpi4py import MPI
import traceback
import sys

if MPI.COMM_WORLD.Get_size() > 1:
    # Ensure that all threads are terminated if one fails

    def mpiexceptabort(type, value, tb):
        traceback.print_exception(type, value, tb)
        MPI.COMM_WORLD.Abort(1)

    sys.excepthook = mpiexceptabort
